db = 'sem2018_marinas'
host = 'baza.fmf.uni-lj.si'
user = 'javnost'
password = 'javnogeslo'